using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelLoader : MonoBehaviour
{
    public Pathfinding pathfinding;
    public InputField levelNameInput;

    public Text txt;

    // Start is called before the first frame update
    private void Start()
    {
        if (PlayerPrefs.GetInt("victory") == 1)
        {
            showToast("You beat the level!", 1);
            PlayerPrefs.SetInt("victory", 0);
        }

        string levelPath = PlayerPrefs.GetString("selectedLevel");
        if (levelPath != "")
        {
            List<string> level = GetLevel(levelPath);
            int levelWidth = 0;
            int levelHight = level.Count;
            for (int i = 0; i < level.Count; i++)
            {
                if (level[i].Length > levelWidth)
                {
                    levelWidth = level[i].Length;
                }
            }
            pathfinding.SetGridParameters(levelWidth, levelHight, level);
            PlayerPrefs.SetString("lastLoadedLevel", levelPath);
            PlayerPrefs.SetString("selectedLevel", "");
        }
    }

    void showToast(string text, int duration)
    {
        StartCoroutine(showToastCOR(text, duration));
    }

    private IEnumerator showToastCOR(string text, int duration)
    {
        Color originalColor = txt.color;

        txt.text = text;
        txt.enabled = true;

        //Fade in
        yield return fadeInAndOut(txt, true, 0.5f, originalColor);

        //Wait for the duration
        float counter = 0;
        while (counter < duration)
        {
            counter += Time.deltaTime;
            yield return null;
        }

        //Fade out
        yield return fadeInAndOut(txt, false, 0.5f, originalColor);

        txt.enabled = false;
        txt.color = originalColor;
    }

    IEnumerator fadeInAndOut(Text targetText, bool fadeIn, float duration, Color originalColor)
    {
        //Set Values depending on if fadeIn or fadeOut
        float a, b;
        if (fadeIn)
        {
            a = 0f;
            b = 1f;
        }
        else
        {
            a = 1f;
            b = 0f;
        }

        originalColor.a = 0;
        Color currentColor = originalColor;
        float counter = 0f;

        while (counter < duration)
        {
            counter += Time.deltaTime;
            float alpha = Mathf.Lerp(a, b, counter / duration);

            targetText.color = new Color(currentColor.r, currentColor.g, currentColor.b, alpha);
            yield return null;
        }
    }

    public void LoadLevel()
    {
        //A basic level select screen can be setup where the application first finds levels in a designated folder and displays them
        string filePath = "";
        string levelName = levelNameInput.text;
        if (levelName != "")
        {
            filePath = GetFile(levelName);
        }
        else
        {
            filePath = GetFile("1"); //Load level 1 if empty for faster testing
        }
        if (filePath != "")
        {
            PlayerPrefs.SetString("selectedLevel", filePath);
            SceneManager.LoadScene("Level");
        }
    }

    /// <summary>
    /// This function finds and returns a path to a file based on the selected file
    /// </summary>
    /// <returns> The path to the selected level </returns>
    internal string GetFile(string name)
    {
        string path = "";


        path = Application.streamingAssetsPath + @"/Levels/" + name + ".txt";

        if (!File.Exists(path))
        {
            levelNameInput.text = "No Such Level";
            path = "";
        }

        return path;
    }


    /// <summary>
    /// This function reads a file and returns the contents in a list
    /// </summary>
    /// <returns> A list of strings that represent the level </returns>
    internal List<string> GetLevel(string path)
    {
        List<string> level = new List<string>();
        string line = "";

        try
        {
            using StreamReader reader = new StreamReader(path);
            while ((line = reader.ReadLine()) != null)
            {
                level.Add(line);
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError(e);
        }

        return level;
    }


}
