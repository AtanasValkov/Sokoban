using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GeneratedGrid : MonoBehaviour
{
    private int[,] gridArray;
    public GameObject cell;
    private List<GameObject> cells = new List<GameObject>();
    private float cellSize;
    private float cellZ = 0.5f;
    private bool playerCreated = false;
    private bool checkedForDeadEndCrates = false;
    public bool canCheckForDeadEndCrates = false;
    private int targetCells = 0;
    private List<Movement> createdCrates = new List<Movement>();
    private int cratesPowered = 0;
    public Text txt;
    GameObject createdCrate = null;

    [Header("Level elements")]
    public GameObject wall;
    public GameObject floor;
    public GameObject target;
    public GameObject playerOnTarget;
    public GameObject player;
    public GameObject crate;
    public GameObject crateOnTarget;

    public void CreateGrid(int width, int height, float cellSize, List<string> level, Pathfinding pathfinding)
    {
        this.cellSize = cellSize;
        level.Reverse();

        gridArray = new int[width, height];

        for (int x = 0; x < gridArray.GetLength(0); x++)
        {
            for (int y = 0; y < gridArray.GetLength(1); y++)
            {
                char levelElement = ' ';
                if (level[y].Length > x)
                {
                    levelElement = level[y].Substring(x, 1)[0];
                }
                switch (levelElement)
                {
                    case 'T':
                        Instantiate(target, GetWorldPosition(x, y), Quaternion.Euler(-90f, 0f, 0f));
                        targetCells++;
                        break;

                    case 'C':
                        createdCrate = Instantiate(crate, GetWorldPosition(x, y), Quaternion.Euler(-90f, 0f, 0f));
                        createdCrates.Add(createdCrate.GetComponentInChildren<Movement>());
                        createdCrate.GetComponentInChildren<Movement>().pathfinding = pathfinding;
                        break;

                    case 'O':
                        createdCrate = Instantiate(crateOnTarget, GetWorldPosition(x, y), Quaternion.Euler(-90f, 0f, 0f));
                        createdCrates.Add(createdCrate.transform.GetChild(1).GetComponent<Movement>());
                        targetCells++;
                        createdCrate.transform.GetChild(1).GetComponent<Movement>().pathfinding = pathfinding;
                        break;

                    case 'P':

                        if (!playerCreated)
                        {
                            Instantiate(player, GetWorldPosition(x, y), Quaternion.Euler(-90f, 0f, 0f));
                            playerCreated = true;
                        }
                        else
                        {
                            Instantiate(floor, GetWorldPosition(x, y), Quaternion.Euler(-90f, 0f, 0f));
                            showToast("Only one Player per Level!", 3);
                        }

                        break;

                    case 'B':

                        if (!playerCreated)
                        {
                            Instantiate(playerOnTarget, GetWorldPosition(x, y), Quaternion.Euler(-90f, 0f, 0f));
                            targetCells++;
                            playerCreated = true;
                        }
                        else
                        {
                            Instantiate(floor, GetWorldPosition(x, y), Quaternion.Euler(-90f, 0f, 0f));
                            showToast("Only one Player per Level!", 3);
                        }
                        break;

                    case 'F':
                        Instantiate(floor, GetWorldPosition(x, y), Quaternion.Euler(-90f, 0f, 0f));

                        break;

                    case 'W':
                        Instantiate(wall, GetWorldPosition(x, y), Quaternion.Euler(-90f, 0f, 0f));

                        break;

                    default:

                        break;

                }
                GameObject createdCell = Instantiate(cell, GetWorldPosition(x, y), Quaternion.identity);
                createdCell.GetComponent<Cell>().grid = this;
                cells.Add(createdCell);
            }
        }
        if (createdCrates.Count == 0)
        {
            showToast("At least one Crate per Level!", 3);
        }
        else if (targetCells == 0)
        {
            showToast("At least one Cell per Level!", 3);
        }
        else if (targetCells < createdCrates.Count)
        {
            showToast("Crates need to be less or equal to the number of targets!", 3);
        }

    }


    private void LateUpdate()
    {
        if (!checkedForDeadEndCrates && canCheckForDeadEndCrates)
        {
            checkedForDeadEndCrates = true;
            foreach (var crate in createdCrates)
            {
                crate.CheckIfReachedDeadEnd();
            }
        }
    }

    void showToast(string text, int duration)
    {
        StartCoroutine(showToastCOR(text, duration));
    }

    private IEnumerator showToastCOR(string text, int duration)
    {
        Color originalColor = txt.color;

        txt.text = text;
        txt.enabled = true;

        //Fade in
        yield return fadeInAndOut(txt, true, 0.5f, originalColor);

        //Wait for the duration
        float counter = 0;
        while (counter < duration)
        {
            counter += Time.deltaTime;
            yield return null;
        }

        //Fade out
        yield return fadeInAndOut(txt, false, 0.5f, originalColor);

        txt.enabled = false;
        txt.color = originalColor;
    }

    IEnumerator fadeInAndOut(Text targetText, bool fadeIn, float duration, Color originalColor)
    {
        //Set Values depending on if fadeIn or fadeOut
        float a, b;
        if (fadeIn)
        {
            a = 0f;
            b = 1f;
        }
        else
        {
            a = 1f;
            b = 0f;
        }

        originalColor.a = 0;
        Color currentColor = originalColor;
        float counter = 0f;

        while (counter < duration)
        {
            counter += Time.deltaTime;
            float alpha = Mathf.Lerp(a, b, counter / duration);

            targetText.color = new Color(currentColor.r, currentColor.g, currentColor.b, alpha);
            yield return null;
        }
    }

    public Vector3 GetWorldPosition(int x, int y)
    {
        return new Vector3(x, y, cellZ) * cellSize;
    }

    public void GetXY(Vector3 worldPosition, out int x, out int y)
    {
        x = Mathf.RoundToInt(worldPosition.x);
        y = Mathf.RoundToInt(worldPosition.y);
    }

    public GameObject GetCell(int x, int y)
    {
        Vector3 location = new Vector3(x, y, cellZ) * cellSize;
        foreach (GameObject cell in cells)
        {
            if (cell.transform.position == location)
            {
                return cell;
            }
        }
        return null;
    }

    public void CratePowered(bool isPowered)
    {
        if (isPowered)
        {
            cratesPowered++;
        }
        else
        {
            cratesPowered--;
        }

        if (cratesPowered == createdCrates.Count)
        {
            StartCoroutine(victoryCoroutine(1));
        }
    }

    private IEnumerator victoryCoroutine(int duration)
    {
        yield return new WaitForSeconds(duration);
        PlayerPrefs.SetInt("victory", 1);
        SceneManager.LoadScene("LevelSelector");
    }
}
