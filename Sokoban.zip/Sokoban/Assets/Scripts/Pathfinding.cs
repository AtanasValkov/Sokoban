using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Pathfinding : MonoBehaviour
{
    public GeneratedGrid grid;
    public Cell cell;
    private List<GameObject> openList;
    private List<GameObject> closedList;
    private const int MOVE_COST = 10;
    private int gridWidth;
    private int gridHeight;
    private GameObject cellObject = null;
    private GameObject crateInCell;

    public void SetGridParameters(int gridWidth, int gridHeight, List<string> level)
    {
        this.gridWidth = gridWidth;
        this.gridHeight = gridHeight;
        grid.CreateGrid(gridWidth, gridHeight, 1f, level, this);
    }
    /// <summary>
    /// Using the A* algorithm without diagonal checks this method finds and returns a list of GameObjects (Cells).
    /// </summary>
    /// <param name="startX"></param>
    /// <param name="startY"></param>
    /// <param name="endX"></param>
    /// <param name="endY"></param>
    /// <param name="isPushing">Whether or not the pushing of crates can happen during the movement.</param>
    /// <returns>A list of GameObjects (Cells) that form an uninterupted path from the provided start to the provided end</returns>
    public List<GameObject> FindPath(int startX, int startY, int endX, int endY, bool isPushing, bool isLookingForTarget)
    {
        GameObject start = grid.GetCell(startX, startY);
        GameObject end = grid.GetCell(endX, endY);
        if (end != null)
        {
            openList = new List<GameObject> { start };
            closedList = new List<GameObject> { };

            for (int x = 0; x < gridWidth; x++)
            {
                for (int y = 0; y < gridHeight; y++)
                {
                    cellObject = grid.GetCell(x, y);
                    cellObject.GetComponent<Cell>().gCost = int.MaxValue;
                    cellObject.GetComponent<Cell>().CalculateFCost();
                    cellObject.GetComponent<Cell>().cameFrom = null;
                }
            }

            start.GetComponent<Cell>().gCost = 0;
            start.GetComponent<Cell>().hCost = Convert.ToInt32(CalculateDistanceCost(start, end));
            start.GetComponent<Cell>().CalculateFCost();

            while (openList.Count > 0)
            {
                
                GameObject current = GetLowestFCostCell(openList);
                
               
                if (current == end)
                {
                    //reached end
                    if (!end.GetComponent<Cell>().isWalkable && isPushing && end.GetComponent<Cell>().isPushable)
                    {
                        crateInCell = end.GetComponent<Cell>().GetCrateInCell();
                    }
                    return CalculatePath(end);
                }

                openList.Remove(current);
                closedList.Add(current);

                foreach (GameObject neighbourCell in GetNeighbourList(current))
                {
                    if(neighbourCell.GetComponent<Cell>().isTarget && !neighbourCell.GetComponent<Cell>().isTargetCovered && isLookingForTarget)
                    {
                        openList.Clear();
                        List<GameObject> listOfTargets = new List<GameObject>();
                        listOfTargets.Add(neighbourCell);
                        return listOfTargets;
                    }
                    if (closedList.Contains(neighbourCell)) continue;
                    if (!neighbourCell.GetComponent<Cell>().isWalkable && !neighbourCell.GetComponent<Cell>().isPushable)
                    {
                        closedList.Add(neighbourCell);
                        continue;
                    }

                    if (!isPushing && !neighbourCell.GetComponent<Cell>().isWalkable)
                    {
                        closedList.Add(neighbourCell);
                        continue;
                    }

                    if (isPushing && neighbourCell != end && !neighbourCell.GetComponent<Cell>().isWalkable)
                    {
                        closedList.Add(neighbourCell);
                        continue;
                    }

                    int tentativeGCost = Convert.ToInt32(current.GetComponent<Cell>().gCost + CalculateDistanceCost(current, neighbourCell));
                    if (tentativeGCost < neighbourCell.GetComponent<Cell>().gCost)
                    {
                        neighbourCell.GetComponent<Cell>().cameFrom = current;
                        neighbourCell.GetComponent<Cell>().gCost = tentativeGCost;
                        neighbourCell.GetComponent<Cell>().hCost = Convert.ToInt32(CalculateDistanceCost(neighbourCell, end));
                        neighbourCell.GetComponent<Cell>().CalculateFCost();

                        if (!openList.Contains(neighbourCell))
                        {
                            openList.Add(neighbourCell);
                        }
                    }
                }
            }
        }

        //out of cells
        return null;
    }

    public GameObject GetCrateInCell()
    {
        GameObject tempCrate = crateInCell;
        crateInCell = null;
        return tempCrate;
    }

    private List<GameObject> GetNeighbourList(GameObject currentCell)
    {
        int x = Convert.ToInt32(currentCell.transform.position.x);
        int y = Convert.ToInt32(currentCell.transform.position.y);
        List<GameObject> neighbourList = new List<GameObject>();

        if (x - 1 >= 0)
        {
            neighbourList.Add(GetCell(x - 1, y));
        }
        if (x + 1 < gridWidth)
        {
            neighbourList.Add(GetCell(x + 1, y));
        }
        if (y - 1 >= 0) neighbourList.Add(GetCell(x, y - 1));
        if (y + 1 < gridHeight) neighbourList.Add(GetCell(x, y + 1));

        return neighbourList;
    }

    private GameObject GetCell(int x, int y)
    {
        return grid.GetCell(x, y);
    }

    public GeneratedGrid GetGrid()
    {
        return grid;
    }

    private List<GameObject> CalculatePath(GameObject end)
    {
        List<GameObject> path = new List<GameObject>();
        path.Add(end);
        GameObject current = end;
        while (current.GetComponent<Cell>().cameFrom != null)
        {
            path.Add(current.GetComponent<Cell>().cameFrom);
            current = current.GetComponent<Cell>().cameFrom;
        }
        path.Reverse();
        return path;
    }

    private float CalculateDistanceCost(GameObject a, GameObject b)
    {
        float xDistance = Mathf.Abs(a.transform.position.x - b.transform.position.x);
        float yDistance = Mathf.Abs(a.transform.position.y - b.transform.position.y);
        float remaining = Mathf.Abs(xDistance - yDistance);
        return Mathf.Min(xDistance, yDistance) + MOVE_COST * remaining;
    }

    private GameObject GetLowestFCostCell(List<GameObject> cellList)
    {
        GameObject lowestFCostCell = cellList[0];
        for (int i = 1; i < cellList.Count; i++)
        {
            if (cellList[i].GetComponent<Cell>().fCost < lowestFCostCell.GetComponent<Cell>().fCost)
            {
                lowestFCostCell = cellList[i];
            }
        }
        return lowestFCostCell;
    }
}
