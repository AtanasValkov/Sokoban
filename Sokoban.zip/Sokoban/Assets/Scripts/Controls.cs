using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Controls : MonoBehaviour
{
    private Pathfinding pathfinding;
    private Movement movement;
    private Vector3 direction;
    private float playerZ = 0f;
    private MoveObject[] storedMovesToUndo;
    private MoveObject[] storedMovesToRedo;
    private int storedMovesToUndoIndex = 0;
    private int storedMovesToRedoIndex = 0;
    private int maxMovesToStore = 100;

    public class MoveObject
    {
        public Movement movement;
        public Vector3[] path;

        public MoveObject(Movement movement, Vector3[] path)
        {
            this.movement = movement;
            this.path = path;
        }
    }

    private void Start()
    {
        pathfinding = GameObject.FindGameObjectWithTag("LevelManager").GetComponent<LevelLoader>().pathfinding;
        movement = transform.GetComponent<Movement>();
        storedMovesToUndo = new MoveObject[maxMovesToStore];
        storedMovesToRedo = new MoveObject[maxMovesToStore];
    }

    void Update()
    {
        if (!movement.GetMovement())
        {
            if (Input.GetMouseButtonDown(0))
            {
                Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                mouseWorldPosition.z = 0.5f;
                CheckForPathAndMove(mouseWorldPosition, false, true, movement);
            }

            if ((Input.GetKeyDown(KeyCode.Comma) && storedMovesToUndoIndex > 0 && storedMovesToRedoIndex < maxMovesToStore) || Input.GetKeyDown(KeyCode.Comma) && storedMovesToUndo[maxMovesToStore - 1] != null)
            {
                UndoLastMove();
            }
            if (Input.GetKeyDown(KeyCode.Period) && storedMovesToRedoIndex > 0)
            {
                RedoLastMove();
            }

            float horizontalInput = Input.GetAxis("Horizontal");
            if (horizontalInput != 0f)
            {
                Decimal horizontalRounded = Math.Round((Decimal)horizontalInput, MidpointRounding.AwayFromZero);
                float horizontalFloat = (float)horizontalRounded;
                direction = new Vector3(horizontalFloat, 0f, playerZ);
                Vector3 target = movement.GetPosition() + direction;
                CheckForPathAndMove(target, true, true, movement);
            }

            float verticalInput = Input.GetAxis("Vertical");
            if (verticalInput != 0f)
            {
                Decimal verticalRounded = Math.Round((Decimal)verticalInput, MidpointRounding.AwayFromZero);
                float verticalFloat = (float)verticalRounded;
                direction = new Vector3(0f, verticalFloat, playerZ);
                Vector3 target = movement.GetPosition() + direction;
                CheckForPathAndMove(target, true, true, movement);
            }

        }
        if (Input.GetKeyDown(KeyCode.R))
        {
            PlayerPrefs.SetString("selectedLevel", PlayerPrefs.GetString("lastLoadedLevel"));
            SceneManager.LoadScene("Level");
        }
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            SceneManager.LoadScene("LevelSelector");
        }
    }

    private void UndoLastMove()
    {
        Vector3[] walkedPath = storedMovesToUndo[storedMovesToUndoIndex - 1].path;
        Array.Reverse(walkedPath);
        storedMovesToUndo[storedMovesToUndoIndex - 1].movement.SetPath(walkedPath);
        if (storedMovesToUndoIndex > 0)
        {
            storedMovesToRedo[storedMovesToRedoIndex] = storedMovesToUndo[storedMovesToUndoIndex - 1];
            storedMovesToUndo[storedMovesToUndoIndex - 1] = null;
            storedMovesToUndoIndex--;
            storedMovesToRedoIndex++;
        }
    }
    private void RedoLastMove()
    {
        Vector3[] walkedPath = storedMovesToRedo[storedMovesToRedoIndex - 1].path;
        Array.Reverse(walkedPath);
        storedMovesToRedo[storedMovesToRedoIndex - 1].movement.SetPath(walkedPath);

        if (storedMovesToRedoIndex > 0)
        {
            storedMovesToUndo[storedMovesToUndoIndex] = storedMovesToRedo[storedMovesToRedoIndex - 1];
            storedMovesToRedo[storedMovesToRedoIndex - 1] = null;
            storedMovesToRedoIndex--;
            storedMovesToUndoIndex++;
        }
    }

    /// <summary>
    /// Checks for a legal path to the target and sets a path for the provided movement component. 
    /// </summary>
    /// <param name="target"> Destination of the movement </param>
    /// <param name="isPushing"> If pushing crates is allowed (only while using WASD) </param>
    /// <param name="isPlayer"> Crates and player share all the logic but it is nice to distinguish them e.g. crates can't push crates </param>
    /// <param name="movement"> The movement script attached to the GameObject requesting the pathfinding </param>
    /// <returns> True when a legal move is found and performed </returns>

    public bool CheckForPathAndMove(Vector3 target, bool isPushing, bool isPlayer, Movement movement)
    {
        pathfinding.GetGrid().GetXY(target, out int x, out int y);
        List<GameObject> path = pathfinding.FindPath(Convert.ToInt32(movement.GetPosition().x), Convert.ToInt32(movement.GetPosition().y), x, y, isPushing, false);
        if (path != null)
        {
            storedMovesToRedo = new MoveObject[maxMovesToStore];
            storedMovesToRedoIndex = 0;
            Vector3[] paths = new Vector3[path.Count];
            for (int i = 0; i < path.Count; i++)
            {
                paths[i] = path[i].transform.position;
            }

            if (isPushing)
            {
                GameObject crateToBePushed = pathfinding.GetCrateInCell();
                if (crateToBePushed != null)
                {
                    //For when a crate needs to move
                    if (CheckForPathAndMove(target + direction, false, false, crateToBePushed.GetComponent<Movement>()))
                    {
                        movement.SetPath(paths);
                        if (storedMovesToUndoIndex >= maxMovesToStore)
                        {
                            //When the array reaches the designated limit of stored moves
                            DeleteFirstStoredMoveAndShiftRemainingMoves();
                        }
                        storedMovesToUndo[storedMovesToUndoIndex] = new MoveObject(movement, paths);
                        storedMovesToUndoIndex++;
                    }
                }
                else
                {
                    //Player moves with WASD
                    if (paths.Length > 1)
                    {
                        movement.SetPath(paths);
                        if (storedMovesToUndoIndex >= maxMovesToStore)
                        {
                            //When the array reaches the designated limit of stored moves
                            DeleteFirstStoredMoveAndShiftRemainingMoves();
                        }

                        //This check is the prevent saving the same move twice
                        int checkPreviousMoveIfDuplicate = storedMovesToUndoIndex - 1;
                        if (checkPreviousMoveIfDuplicate < 0)
                        {
                            checkPreviousMoveIfDuplicate = 0;
                        }

                        if (storedMovesToUndo[checkPreviousMoveIfDuplicate] != null)
                        {
                            if (storedMovesToUndo[checkPreviousMoveIfDuplicate].path != paths)
                            {
                                storedMovesToUndo[storedMovesToUndoIndex] = new MoveObject(movement, paths);
                                storedMovesToUndoIndex++;
                            }
                        }
                        else
                        {
                            storedMovesToUndo[storedMovesToUndoIndex] = new MoveObject(movement, paths);
                            storedMovesToUndoIndex++;
                        }
                    }
                }
            }
            else
            {
                //Player moves with mouse
                movement.SetPath(paths);
                if (storedMovesToUndoIndex >= maxMovesToStore)
                {
                    //When the array reaches the designated limit of stored moves
                    DeleteFirstStoredMoveAndShiftRemainingMoves();
                }
                storedMovesToUndo[storedMovesToUndoIndex] = new MoveObject(movement, paths);
                storedMovesToUndoIndex++;
            }

            return true;
        }
        return false;
    }
    /// <summary>
    /// When trying to add more than the max amount of elements the method removes the move stored at position 0
    /// and shifts the array elemnts back one position, leaving the last spot empty.
    /// </summary>
    private void DeleteFirstStoredMoveAndShiftRemainingMoves()
    {
        storedMovesToUndo[0] = null;
        var nullMove = storedMovesToUndo.Where(x => x == null);
        var storedMoves = storedMovesToUndo.Where(x => x != null);
        storedMovesToUndo = storedMoves.Concat(nullMove).ToArray();
        storedMovesToUndoIndex--;
    }
}
