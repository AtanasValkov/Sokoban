using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cell : MonoBehaviour
{
    public GameObject wall;
    public GameObject crate;
    public GameObject target;
    private GameObject crateInCell;
    public Material poweredCrate;
    public Material unpoweredCrate;
    public int gCost;
    public int fCost;
    public int hCost;
    public bool isWalkable = true;
    public bool isPushable = false;
    public bool isTarget = false;
    public bool isTargetCovered = false;

    public GameObject cameFrom;
    public GeneratedGrid grid;

    public void CalculateFCost()
    {
        fCost = gCost + hCost;
    }

    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.layer == wall.layer)
        {
            isWalkable = false;
        }

        if (collision.gameObject.layer == target.layer)
        {
            isTarget = true;
            gameObject.layer = 7;
            grid.canCheckForDeadEndCrates = true;
        }

        if (collision.gameObject.layer == crate.layer)
        {
            isWalkable = false;
            isPushable = true;
            crateInCell = collision.gameObject;
            if (isTarget)
            {
                collision.gameObject.GetComponent<Renderer>().material = poweredCrate;
                collision.gameObject.GetComponent<Movement>().SetOnTarget(true);
                grid.CratePowered(true);
                isTargetCovered = true;
            }
        }
    }

    private void OnTriggerExit(Collider collision)
    {
        if (collision.gameObject.layer == crate.layer)
        {
            isWalkable = true;
            isPushable = false;
            crateInCell = null;
            if (isTarget)
            {
                collision.gameObject.GetComponent<Renderer>().material = unpoweredCrate;
                collision.gameObject.GetComponent<Movement>().SetOnTarget(false);
                grid.CratePowered(false);
                isTargetCovered = false;
            }
        }
    }

    public GameObject GetCrateInCell()
    {
        return crateInCell;
    }
}
