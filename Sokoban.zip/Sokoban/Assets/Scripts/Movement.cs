using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;

public class Movement : MonoBehaviour
{
    private float speed = 4f;
    private int currentPathIndex;
    private Vector3[] pathVectorList;
    private bool isMoving = false;
    private float playerZ = 0f;
    private float crateZ = 0.25f;
    public GameObject crate;
    public bool isOnTarget = false;
    public bool isImmovable = false;
    public Material deadEndCrateMaterial;
    public Material defaultCrateMaterial;
    private Vector3[] directions;
    private List<Vector3> blockedDirections;
    public Pathfinding pathfinding;

    private void Awake()
    {
        isMoving = false;
        directions = new Vector3[] { Vector3.left, Vector3.right, Vector3.up, Vector3.down };
        defaultCrateMaterial = GetComponent<Renderer>().material;
    }

    private void Update()
    {
        if (pathVectorList != null)
        {
            StartMoving();
        }
    }

    private void StartMoving()
    {

        if (currentPathIndex <= pathVectorList.Length - 1)
        {
            if (gameObject.layer == crate.layer)
            {
                pathVectorList[currentPathIndex + 1].z = crateZ;
            }
            else
            {
                pathVectorList[currentPathIndex + 1].z = playerZ;
            }
            gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, pathVectorList[currentPathIndex + 1], speed * Time.deltaTime);
        }

        if (gameObject.transform.position == pathVectorList[currentPathIndex + 1])
        {
            currentPathIndex++;
        }

        if (currentPathIndex >= pathVectorList.Length - 1)
        {
            StopMoving();
        }
    }

    public void StopMoving()
    {
        currentPathIndex = -1;
        pathVectorList = null;
        isMoving = false;
        if (gameObject.layer == crate.layer && !isOnTarget)
        {
            CheckIfReachedDeadEnd();
        }
    }

    public bool CheckIfReachedDeadEnd()
    {
        int layerCrate = 9;
        int layerWall = 6;
        int layerTarget = 7;
        int layerMaskTarget = (1 << layerTarget);

        int layerMaskCombined = (1 << layerCrate) | (1 << layerWall);

        RaycastHit hit;
        blockedDirections = new List<Vector3>();
        Collider colliderOfObstacle = null;
        for (int i = 0; i < directions.Length; i++)
        {
            if (Physics.Raycast(gameObject.transform.position, directions[i], out hit, 1f, layerMaskCombined, QueryTriggerInteraction.Ignore))
            {
                colliderOfObstacle = hit.collider;

                if (colliderOfObstacle.GetComponent<Movement>() != null) //Crate
                {
                    if (colliderOfObstacle.GetComponent<Movement>().isImmovable) //If crate is considered immovable
                    {
                        blockedDirections.Add(directions[i]);
                    }
                }
                else //Wall
                {
                    blockedDirections.Add(directions[i]);
                }

                if (blockedDirections.Count > 2) //Surrounded by 3 walls or immovable crates is considered immovable
                {
                    GetComponent<Renderer>().material = deadEndCrateMaterial;
                    isImmovable = true;
                    return true;
                }
                else if (blockedDirections.Count == 2) //Being in a corner of walls or immovable crates is considered immovable
                {
                    if (blockedDirections[0] == Vector3.left && blockedDirections[1] == Vector3.up || blockedDirections[0] == Vector3.left && blockedDirections[1] == Vector3.down)
                    {
                        GetComponent<Renderer>().material = deadEndCrateMaterial;
                        isImmovable = true;
                        return true;
                    }
                    else if (blockedDirections[0] == Vector3.right && blockedDirections[1] == Vector3.up || blockedDirections[0] == Vector3.right && blockedDirections[1] == Vector3.down)
                    {
                        GetComponent<Renderer>().material = deadEndCrateMaterial;
                        isImmovable = true;
                        return true;
                    }
                }
            }
        }

        if (blockedDirections.Count == 1) //Touching a wall or immovable crate and having no target to the sides is considered immovable
        {
            Vector3[] wallDirections = new Vector3[2];
            for (int i = 0; i < directions.Length; i++)
            {
                if (directions[i] == blockedDirections[0])
                {
                    switch (i)
                    {
                        case 0: //left
                            wallDirections[0] = Vector3.up;
                            wallDirections[1] = Vector3.down;
                            break;
                        case 1: //right
                            wallDirections[0] = Vector3.up;
                            wallDirections[1] = Vector3.down;
                            break;
                        case 2: //up
                            wallDirections[0] = Vector3.left;
                            wallDirections[1] = Vector3.right;
                            break;
                        case 3: //down
                            wallDirections[0] = Vector3.left;
                            wallDirections[1] = Vector3.right;
                            break;
                        default:
                            break;
                    }
                }
            }
            bool targetDetected = false;
            for (int z = 0; z < wallDirections.Length; z++)
            {
                if (Physics.Raycast(gameObject.transform.position, wallDirections[z], out hit, Mathf.Infinity, layerMaskTarget, QueryTriggerInteraction.Collide))
                {
                    targetDetected = true;
                }
            }
            if (!targetDetected)
            {
                GetComponent<Renderer>().material = deadEndCrateMaterial;
                isImmovable = true;
                return true;
            }
        }
        GetComponent<Renderer>().material = defaultCrateMaterial;
        isImmovable = false;
        return false;
    }

    public Vector3 GetPosition()
    {
        return gameObject.transform.position;
    }

    public bool GetMovement()
    {
        return isMoving;
    }

    public void SetOnTarget(bool isOnTarget)
    {
        this.isOnTarget = isOnTarget;
        defaultCrateMaterial = GetComponent<Renderer>().material;
    }

    public void SetPath(Vector3[] list)
    {
        isMoving = true;
        currentPathIndex = -1;
        pathVectorList = list;
    }
}
